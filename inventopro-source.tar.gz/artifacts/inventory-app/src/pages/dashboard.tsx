import { 
  useGetDashboardStats, 
  useGetSalesTrend, 
  useGetTopProducts, 
  useGetRecentTransactions 
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  IndianRupee, ShoppingCart, Package, AlertTriangle, 
  TrendingUp, Users, ArrowUpRight, ArrowDownRight, Clock
} from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";
import { format } from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useGetDashboardStats();
  const { data: trendData, isLoading: trendLoading } = useGetSalesTrend();
  const { data: topProducts, isLoading: topLoading } = useGetTopProducts();
  const { data: recent, isLoading: recentLoading } = useGetRecentTransactions();

  if (statsLoading || trendLoading) return <DashboardSkeleton />;

  const formatCurrency = (val: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(val);

  const kpis = [
    { title: "Monthly Revenue", value: formatCurrency(stats?.monthlyRevenue || 0), icon: IndianRupee, color: "text-emerald-500", bg: "bg-emerald-500/10" },
    { title: "Today's Sales", value: formatCurrency(stats?.todaySales || 0), icon: TrendingUp, color: "text-blue-500", bg: "bg-blue-500/10" },
    { title: "Today's Purchases", value: formatCurrency(stats?.todayPurchases || 0), icon: ShoppingCart, color: "text-indigo-500", bg: "bg-indigo-500/10" },
    { title: "Low Stock Items", value: stats?.lowStockItems || 0, icon: AlertTriangle, color: "text-rose-500", bg: "bg-rose-500/10" },
    { title: "Pending Payments", value: formatCurrency(stats?.pendingPayments || 0), icon: Clock, color: "text-amber-500", bg: "bg-amber-500/10" },
    { title: "Total Products", value: stats?.totalProducts || 0, icon: Package, color: "text-slate-500", bg: "bg-slate-500/10" },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {kpis.map((kpi, i) => (
          <Card key={i} className="rounded-2xl border-border/50 shadow-sm hover:shadow-md transition-shadow overflow-hidden group">
            <CardContent className="p-6 flex items-center gap-4 relative">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${kpi.bg}`}>
                <kpi.icon className={`w-7 h-7 ${kpi.color}`} />
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground mb-1">{kpi.title}</p>
                <h3 className="text-2xl font-bold text-foreground font-display">{kpi.value}</h3>
              </div>
              <div className="absolute -right-4 -bottom-4 opacity-5 group-hover:scale-110 transition-transform">
                <kpi.icon className="w-32 h-32" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-1 lg:col-span-2 rounded-2xl border-border/50 shadow-sm">
          <CardHeader>
            <CardTitle>Sales vs Purchases (30 Days)</CardTitle>
            <CardDescription>Daily comparison of inflow and outflow</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={trendData || []} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorPurchases" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    tickFormatter={(val) => format(new Date(val), "MMM dd")}
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                    dy={10}
                  />
                  <YAxis 
                    tickFormatter={(val) => `₹${val/1000}k`}
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 12 }}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    labelFormatter={(val) => format(new Date(val), "MMM dd, yyyy")}
                    formatter={(val: number) => [formatCurrency(val), ""]}
                  />
                  <Area type="monotone" name="Sales" dataKey="sales" stroke="hsl(var(--primary))" strokeWidth={3} fillOpacity={1} fill="url(#colorSales)" />
                  <Area type="monotone" name="Purchases" dataKey="purchases" stroke="#f43f5e" strokeWidth={3} fillOpacity={1} fill="url(#colorPurchases)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-border/50 shadow-sm flex flex-col">
          <CardHeader>
            <CardTitle>Top Products</CardTitle>
            <CardDescription>By revenue this month</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 overflow-auto">
            <div className="space-y-4">
              {topProducts?.map((product, i) => (
                <div key={product.id} className="flex items-center justify-between group">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-secondary text-secondary-foreground flex items-center justify-center font-bold text-xs">
                      #{i + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sm text-foreground line-clamp-1 group-hover:text-primary transition-colors">{product.name}</p>
                      <p className="text-xs text-muted-foreground">{product.totalQuantity} sold</p>
                    </div>
                  </div>
                  <div className="font-semibold text-sm">
                    {formatCurrency(product.totalRevenue)}
                  </div>
                </div>
              ))}
              {(!topProducts || topProducts.length === 0) && (
                <div className="text-center py-8 text-muted-foreground text-sm">No sales data available yet</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl border-border/50 shadow-sm">
        <CardHeader>
          <CardTitle>Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-secondary/50 rounded-lg">
                <tr>
                  <th className="px-4 py-3 font-medium rounded-l-lg">Invoice</th>
                  <th className="px-4 py-3 font-medium">Type</th>
                  <th className="px-4 py-3 font-medium">Party</th>
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3 font-medium text-right rounded-r-lg">Amount</th>
                </tr>
              </thead>
              <tbody>
                {recent?.map((tx) => (
                  <tr key={`${tx.type}-${tx.id}`} className="border-b border-border/50 last:border-0 hover:bg-muted/50 transition-colors">
                    <td className="px-4 py-4 font-medium text-foreground">{tx.invoiceNo}</td>
                    <td className="px-4 py-4">
                      <Badge variant="outline" className={tx.type === 'sale' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-200' : 'bg-rose-500/10 text-rose-600 border-rose-200'}>
                        {tx.type === 'sale' ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
                        <span className="capitalize">{tx.type}</span>
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-muted-foreground">{tx.partyName}</td>
                    <td className="px-4 py-4 text-muted-foreground">{format(new Date(tx.date), 'dd MMM yyyy')}</td>
                    <td className="px-4 py-4 font-semibold text-right">{formatCurrency(tx.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {(!recent || recent.length === 0) && (
              <div className="text-center py-8 text-muted-foreground text-sm">No recent transactions</div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="h-28 rounded-2xl" />)}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Skeleton className="col-span-2 h-[400px] rounded-2xl" />
        <Skeleton className="h-[400px] rounded-2xl" />
      </div>
    </div>
  );
}

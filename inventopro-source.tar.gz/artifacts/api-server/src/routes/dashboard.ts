import { Router, type IRouter } from "express";
import { sql, desc, gte } from "drizzle-orm";
import { db, salesTable, purchasesTable, productsTable, customersTable, suppliersTable, saleItemsTable } from "@workspace/db";
import {
  GetDashboardStatsResponse,
  GetSalesTrendResponse,
  GetTopProductsResponse,
  GetRecentTransactionsResponse,
} from "@workspace/api-zod";
import { authMiddleware } from "../lib/auth";

const router: IRouter = Router();

router.get("/dashboard/stats", authMiddleware, async (_req, res): Promise<void> => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

  const [todaySalesResult] = await db.select({
    total: sql<number>`COALESCE(SUM(grand_total::numeric), 0)`
  }).from(salesTable).where(gte(salesTable.saleDate, today));

  const [todayPurchasesResult] = await db.select({
    total: sql<number>`COALESCE(SUM(grand_total::numeric), 0)`
  }).from(purchasesTable).where(gte(purchasesTable.invoiceDate, today));

  const [lowStockResult] = await db.select({
    count: sql<number>`count(*)::int`
  }).from(productsTable).where(sql`${productsTable.currentStock}::numeric <= ${productsTable.minStockAlert}::numeric AND ${productsTable.active} = true`);

  const [pendingPaymentsResult] = await db.select({
    total: sql<number>`COALESCE(SUM(balance_due::numeric), 0)`
  }).from(salesTable).where(sql`${salesTable.paymentStatus} != 'paid'`);

  const [totalProductsResult] = await db.select({
    count: sql<number>`count(*)::int`
  }).from(productsTable);

  const [totalCustomersResult] = await db.select({
    count: sql<number>`count(*)::int`
  }).from(customersTable);

  const [totalSuppliersResult] = await db.select({
    count: sql<number>`count(*)::int`
  }).from(suppliersTable);

  const [monthlyRevenueResult] = await db.select({
    total: sql<number>`COALESCE(SUM(grand_total::numeric), 0)`
  }).from(salesTable).where(gte(salesTable.saleDate, monthStart));

  res.json({
    todaySales: Number(todaySalesResult.total),
    todayPurchases: Number(todayPurchasesResult.total),
    lowStockItems: lowStockResult.count,
    pendingPayments: Number(pendingPaymentsResult.total),
    totalProducts: totalProductsResult.count,
    totalCustomers: totalCustomersResult.count,
    totalSuppliers: totalSuppliersResult.count,
    monthlyRevenue: Number(monthlyRevenueResult.total),
  });
});

router.get("/dashboard/sales-trend", authMiddleware, async (_req, res): Promise<void> => {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  const salesTrend = await db.execute(sql`
    WITH dates AS (
      SELECT generate_series(
        ${thirtyDaysAgo}::date,
        CURRENT_DATE,
        '1 day'::interval
      )::date AS date
    )
    SELECT
      d.date::text,
      COALESCE((SELECT SUM(grand_total::numeric) FROM sales WHERE sale_date::date = d.date), 0) as sales,
      COALESCE((SELECT SUM(grand_total::numeric) FROM purchases WHERE invoice_date::date = d.date), 0) as purchases
    FROM dates d
    ORDER BY d.date
  `);

  res.json(
    salesTrend.rows.map((r: any) => ({
      date: r.date,
      sales: Number(r.sales),
      purchases: Number(r.purchases),
    }))
  );
});

router.get("/dashboard/top-products", authMiddleware, async (_req, res): Promise<void> => {
  const topProducts = await db.execute(sql`
    SELECT
      p.id,
      p.name,
      COALESCE(SUM(si.quantity::numeric), 0) as total_quantity,
      COALESCE(SUM(si.total::numeric), 0) as total_revenue
    FROM products p
    LEFT JOIN sale_items si ON si.product_id = p.id
    GROUP BY p.id, p.name
    HAVING COALESCE(SUM(si.quantity::numeric), 0) > 0
    ORDER BY total_revenue DESC
    LIMIT 10
  `);

  res.json(
    topProducts.rows.map((r: any) => ({
      id: Number(r.id),
      name: r.name,
      totalQuantity: Number(r.total_quantity),
      totalRevenue: Number(r.total_revenue),
    }))
  );
});

router.get("/dashboard/recent-transactions", authMiddleware, async (_req, res): Promise<void> => {
  const recentSales = await db.select({
    id: salesTable.id,
    invoiceNo: salesTable.invoiceNo,
    partyName: salesTable.customerName,
    amount: salesTable.grandTotal,
    date: salesTable.saleDate,
  }).from(salesTable).orderBy(desc(salesTable.createdAt)).limit(5);

  const recentPurchases = await db
    .select({
      id: purchasesTable.id,
      invoiceNo: purchasesTable.invoiceNo,
      partyName: suppliersTable.name,
      amount: purchasesTable.grandTotal,
      date: purchasesTable.invoiceDate,
    })
    .from(purchasesTable)
    .leftJoin(suppliersTable, sql`${purchasesTable.supplierId} = ${suppliersTable.id}`)
    .orderBy(desc(purchasesTable.createdAt))
    .limit(5);

  const transactions = [
    ...recentSales.map(s => ({
      id: s.id,
      type: "sale" as const,
      invoiceNo: s.invoiceNo,
      partyName: s.partyName,
      amount: Number(s.amount),
      date: s.date.toISOString().split("T")[0],
    })),
    ...recentPurchases.map(p => ({
      id: p.id,
      type: "purchase" as const,
      invoiceNo: p.invoiceNo,
      partyName: p.partyName || "Unknown",
      amount: Number(p.amount),
      date: p.date.toISOString().split("T")[0],
    })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 10);

  res.json(transactions);
});

export default router;
